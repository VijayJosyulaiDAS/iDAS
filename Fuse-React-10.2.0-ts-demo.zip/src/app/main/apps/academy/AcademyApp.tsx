import { Outlet } from 'react-router-dom';

/**
 * The Academy app.
 */
function AcademyApp() {
	return <Outlet />;
}

export default AcademyApp;
