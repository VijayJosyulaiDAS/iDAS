import { Outlet } from 'react-router-dom';

/**
 * The E-Commerce app.
 */
function ECommerceApp() {
	return <Outlet />;
}

export default ECommerceApp;
