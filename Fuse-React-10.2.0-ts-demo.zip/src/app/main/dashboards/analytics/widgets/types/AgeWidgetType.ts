/**
 * Age Widget Type
 */
type AgeWidgetType = {
	uniqueVisitors?: number;
	series?: number[];
	labels?: string[];
};

export default AgeWidgetType;
