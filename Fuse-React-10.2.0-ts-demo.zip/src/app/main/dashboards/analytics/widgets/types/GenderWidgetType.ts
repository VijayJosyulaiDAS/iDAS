/**
 * Gender Widget Type
 */
type GenderWidgetType = {
	uniqueVisitors: number;
	series: number[];
	labels: string[];
};

export default GenderWidgetType;
