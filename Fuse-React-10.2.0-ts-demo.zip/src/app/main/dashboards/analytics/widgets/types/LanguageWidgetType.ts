/**
 * Language Widget Type
 */
type LanguageWidgetType = {
	uniqueVisitors: number;
	series: number[];
	labels: string[];
};

export default LanguageWidgetType;
