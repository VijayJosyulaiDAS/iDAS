/**
 * New Vs Returning Widget Type
 */
type NewVsReturningWidgetType = {
	uniqueVisitors: number;
	series: number[];
	labels: string[];
};

export default NewVsReturningWidgetType;
