import BtcMainChart from './widgets/BTCMainChart';

/**
 * Crypto Dashboard App Content
 */
function CryptoDashboardAppContent() {
	return <BtcMainChart />;
}

export default CryptoDashboardAppContent;
