type CoinTypes = 'btc' | 'eth' | 'bch' | 'xrp';

export default CoinTypes;
