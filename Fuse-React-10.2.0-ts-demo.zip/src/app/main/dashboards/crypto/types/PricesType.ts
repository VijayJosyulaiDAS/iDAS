/**
 * PricesType
 */
type PricesType = {
	btc: number;
	eth: number;
	bch: number;
	xrp: number;
};

export default PricesType;
