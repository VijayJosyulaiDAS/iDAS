/**
 * WalletsType
 */
type WalletsType = {
	btc: number;
	eth: number;
	bch: number;
	xrp: number;
};

export default WalletsType;
