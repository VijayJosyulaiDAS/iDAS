import * as history from 'history';

/**
 * The default history object for the Fuse project.
 */
export default history.createBrowserHistory();
