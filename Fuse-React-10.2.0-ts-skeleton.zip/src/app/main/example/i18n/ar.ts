const locale = {
	TITLE: 'مثال على الصفحة'
};

export default locale;
